@extends('user.layout.navbar')
@section('content')
<style>
.select-design-checkbox
{
 width: 15px; /* Set the desired width */
    height: 15px;

/* Set the desired height */
}
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
}

/* Modal Content (image) */
.modal-content {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
}

/* Caption of Modal Image */
#caption {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
  text-align: center;
  color: #ccc;
  padding: 10px 0;
  height: 150px;
}

/* Add Animation */
.modal-content, #caption { 
  animation-name: zoom;
  animation-duration: 0.6s;
}

@keyframes zoom {
  from {transform:scale(0)} 
  to {transform:scale(1)}
}

/* Close Button */
.close {
  position: absolute;
  top: 115px;
  right: 35px;
  color: #f1f1f1;
  font-size: 40px;
  font-weight: bold;
  transition: 0.3s;
}

.close:hover,
.close:focus {
  color: #bbb;
  text-decoration: none;
  cursor: pointer;
}
     .portfolio-design {
        position: relative;
    }

    .buttons-container {
        position: absolute;
        bottom: 10px;
        right: 20px;
        display: none;
    padding-left:10px;
     padding-right:10px;
     padding-top:10px;
     padding-bottom:10px;
    background-color:lightgreen;
    }

    .portfolio-design:hover .buttons-container {
        display: block;
    }

    .view-full-design-btn,
    .select-design-btn {
        background-color: #ffffff;
        border: 1px solid #4bb750;
        padding: 5px 10px;
        border-radius: 5px;
        font-size: 12px;
        cursor: pointer;
        margin-left: 5px;
    }

    /* Your existing styles */
    .active {
        background-color: #4bb750;
    }

    .custom-btn {
        font-size: 10px;
        padding: 3px;
    }

    /* Added CSS for sub-categories */
    .sub-category {
        cursor: pointer;
        padding: 5px;
        margin: 5px 0;
        border-radius: 5px;
        background-color: #f0f0f0;
        transition: background-color 0.3s ease;
    }

    .sub-category:hover {
        background-color: #e0e0e0;
    }

    /* Added CSS for portfolio designs */
    .portfolio-design-img {
    max-width: 100%;
        min-width: 100%;
        max-height: 40vh;
     min-height: 40vh;/* Set a fixed height */
        object-fit: cover; /* Ensure the image covers the container */
        border-radius: 5px;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
        transition: transform 0.3s ease;
    }

    .portfolio-design-img:hover {
        transform: scale(1.05);
    }
.image {
    max-width: 100%;
    min-width: 100%;

    transition: transform 0.3s ease, box-shadow 0.3s ease; /* Add box-shadow transition */
}
.image:hover {
    transform: scale(1.05); /* Zoom effect on hover */
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); /* Add box shadow on hover */
}

#stickyBar {
    display: none;
    position: fixed;
    bottom: 0;
    left: 50%; /* Position it at the horizontal center */
    transform: translateX(-50%); /* Adjust to center it properly */
    width: 80%; /* Set the desired width */
    max-width: 700px; /* Adjust the maximum width as needed */
    padding: 10px 0;
    background-color: #f8f9fa; /* Bootstrap background color */
    box-shadow: 0px -2px 5px rgba(0, 0, 0, 0.2); /* Add a shadow effect */
    z-index: 999; /* Ensure the sticky bar is above other content */
}

  .heading2
  {
  background-color:lightgreen;
  }  
</style>



<div class="row">
    @foreach ($categories['data'] as $category)
        <div class="col-lg-12 col-md-12 col-sm-12 mb-3">
            <h2 class="heading2 my-4">{{ $category['name'] }}</h2>
            <div class="container">
                <div class="row">
                    @foreach ($category['main_image']['data'] as $mainImage)
                        <div class="col-lg-3 col-md-3 col-sm-12 mb-3">
                            <div class="portfolio-design">
                                <a href="https://webexcels.pk/drm/assets/posting_data/{{ $mainImage['img'] }}" target="blank">
                                    <img class="img-fluid image portfolio-design-img" src="https://webexcels.pk/drm/assets/posting_data/{{ $mainImage['img'] }}" alt="Main Image">
                                </a>
                                <div class="buttons-container">
                                    <label> <b>Select</b></label>
                                    <input type="checkbox" class="select-design-checkbox" value="https://webexcels.pk/drm/assets/posting_data/{{ $mainImage['img'] }}">
                                </div>
                            </div>
                            <div class="mt-2">
                                <h3>Views</h3>
                                <div class="row">
                                    <?php
                                    // Fetch views for the main image using its id
                                    $mainImageId = $mainImage['id'];
                                    $viewsResponse = Http::get('https://webexcels.pk/api/products-main-image-views/' . $mainImageId);
                                    $views = $viewsResponse->json();
                                    ?>
                                    @if(isset($views['data']))
                                        @foreach ($views['data'] as $view)
                                            <div class="col-lg-2 col-md-2 col-sm-2 col-4">
                                                <a href="https://webexcels.pk/drm/assets/posting_data/{{ $view['images'] }}" target="blank">
                                                    <img class="img-fluid image" src="https://webexcels.pk/drm/assets/posting_data/{{ $view['images'] }}" alt="View Image">
                                                </a>
                                            </div>
                                        @endforeach
                                    @else
                                        <div class="col-12">
                                            <p>No views available</p>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    @endforeach
</div>

<div id="stickyBar" class="container">
    <center>
        <button id="submitImagesBtn" class="btn btn-primary">Submit</button>
    </center>
</div>

<!-- Pagination Links -->
<div>
    @if ($categories['current_page'] > 1)
        <a href="?page={{ $categories['current_page'] - 1 }}">Previous</a>
    @endif

    @if ($categories['current_page'] < $categories['last_page'])
        <a href="?page={{ $categories['current_page'] + 1 }}">Next</a>
    @endif
</div>
                 
                    <script>
    $(document).ready(function () {
        // Handle checkbox selection
        $('.portfolio-design').hover(function () {
            $(this).find('.buttons-container').show();
        }, function () {
            $(this).find('.buttons-container').hide();
        });

        // Show sticky bar when image is selected
        $('.select-design-checkbox').change(function () {
            if ($('.select-design-checkbox:checked').length > 0) {
                $('#stickyBar').show();
            } else {
                $('#stickyBar').hide();
            }
        });

        // AJAX request to save selected images
        $('#submitImagesBtn').click(function (e) {
            e.preventDefault(); // Prevent default form submission
            var selectedImages = [];
            $('.select-design-checkbox:checked').each(function () {
                selectedImages.push($(this).val());
            });

            // Include CSRF token
            var csrfToken = $('meta[name="csrf-token"]').attr('content');

            $.ajax({
                url: '{{ route("user.productstoredesign") }}', // Use Laravel named route
                type: 'POST',
                data: {
                    _token: csrfToken, // Pass the CSRF token
                    images: selectedImages
                },
                success: function (response) {
                    console.log(response);
                    // Handle success response
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                    // Handle error response
                }
            });
        });
    });
</script>
@endsection
