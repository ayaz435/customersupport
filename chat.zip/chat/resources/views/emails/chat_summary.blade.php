<!DOCTYPE html>
<html>
<head>
    <title>Chat Summary</title>
</head>
<body>
    <p>Hello Zunair,</p>
    <p>Here is your chat summary:</p>
    <ul>
        <li><strong>Start Date:</strong> {{ $start_date }}</li>
        <li><strong>Current Date:</strong> {{ $current_date }}</li>
    </ul>
    <p>Best regards,</p>
    <p>Your Application</p>
</body>
</html>
