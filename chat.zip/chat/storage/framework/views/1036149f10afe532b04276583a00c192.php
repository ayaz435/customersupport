<!DOCTYPE html>
<html>
<head>
    <title>Chat Summary</title>
</head>
<body>
    <p>Hello Zunair,</p>
    <p>Here is your chat summary:</p>
    <ul>
        <li><strong>Start Date:</strong> <?php echo e($start_date); ?></li>
        <li><strong>Current Date:</strong> <?php echo e($current_date); ?></li>
    </ul>
    <p>Best regards,</p>
    <p>Your Application</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\customersupport\chat\resources\views/emails/chat_summary.blade.php ENDPATH**/ ?>