
<?php /**PATH /home/xlserp/public_html/customersupport/chat/resources/views/components/application-logo.blade.php ENDPATH**/ ?>