
<?php if($get == 'saved'): ?>
    <table class="messenger-list-item" data-contact="<?php echo e(Auth::user()->id); ?>">
        <tr data-action="0">
            
            <td>
                <div class="saved-messages avatar av-m">
                    <span class="far fa-bookmark"></span>
                </div>
            </td>
            
            <td>
                <p data-id="<?php echo e(Auth::user()->id); ?>" data-type="user">Saved Messages <span>You</span></p>
                <span>Save messages secretly</span>
            </td>
        </tr>
    </table>
<?php endif; ?>



<?php if($get == 'users' && !!$lastMessage): ?>
    <?php
    $lastMessageBody = mb_convert_encoding($lastMessage->body, 'UTF-8', 'UTF-8');
    $lastMessageBody = strlen($lastMessageBody) > 30 ? mb_substr($lastMessageBody, 0, 30, 'UTF-8').'..' : $lastMessageBody;
    ?>
    <table class="messenger-list-item" data-contact="<?php echo e($user->id); ?>">
        <tr data-action="0">

            
            <td style="position: relative">
                <?php if($user->active_status): ?>
                    <span class="activeStatus"></span>
                <?php endif; ?>
                <div class="avatar av-m" style="background-image: url('<?php echo e($user->avatar); ?>');"></div>
            </td>
            
            <td>
                <p data-id="<?php echo e($user->id); ?>" data-type="user">
             <?php if(Auth::user()->role === 'team'): ?>
          <?php echo e(strlen($user->cname) > 12 ? trim(substr($user->cname,0,12)).'..' : $user->cname); ?>

        <?php elseif(Auth::user()->role === 'user'): ?>
          <?php echo e(strlen($user->name) > 12 ? trim(substr($user->name,0,12)).'..' : $user->name); ?>

        <?php endif; ?>
                    
                    <span style="font-size:10px;" class=" text-danger" data-time="<?php echo e($lastMessage->created_at); ?>"><?php
    $datetime = $lastMessage->created_at;
   $date = \Carbon\Carbon::parse($datetime)->setTimezone('Asia/Karachi')->format('Y-m-d');
    $time = \Carbon\Carbon::parse($datetime)->setTimezone('Asia/Karachi')->format('h:i:s A');
?>

<?php echo e($date); ?><br>
<?php echo e($time); ?></span>
                </p>
                <span>
                    
                    <?php echo $lastMessage->from_id == Auth::user()->id ? '<span class="lastMessageIndicator">You :</span>' : ''; ?>

                    
                    <?php if($lastMessage->attachment == null): ?>
                        <?php echo $lastMessageBody; ?>

                    <?php else: ?>
                        <span class="fas fa-file"></span> Attachment
                    <?php endif; ?>
                </span>
                
                <?php echo $unseenCounter > 0 ? '<b class="bg-danger">' . $unseenCounter . '</b>' : ''; ?>

            </td>
        </tr>
    </table>
<?php endif; ?>


<?php if($get == 'search_item'): ?>
    <table class="messenger-list-item" data-contact="<?php echo e($user->id); ?>">
        <tr data-action="0">
            
            <td>
                <div class="avatar av-m" style="background-image: url('<?php echo e($user->avatar); ?>');"></div>
            </td>
            
            <td>
             <?php if(Auth::user()->role === 'team'): ?>
            <p data-id="<?php echo e($user->id); ?>" data-type="user">
                    <?php echo e(strlen($user->cname) > 12 ? trim(substr($user->cname,0,12)).'..' : $user->cname); ?>

                </p>
        <?php elseif(Auth::user()->role === 'user'): ?>
            <p data-id="<?php echo e($user->id); ?>" data-type="user">
                    <?php echo e(strlen($user->name) > 12 ? trim(substr($user->name,0,12)).'..' : $user->name); ?>

                </p>
        <?php endif; ?>
                
            </td>
        </tr>
    </table>
<?php endif; ?>


<?php if($get == 'sharedPhoto'): ?>
    <div class="shared-photo chat-image" style="background-image: url('<?php echo e($image); ?>')"></div>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\customersupport\chat\resources\views/vendor/Chatify/layouts/listItem.blade.php ENDPATH**/ ?>