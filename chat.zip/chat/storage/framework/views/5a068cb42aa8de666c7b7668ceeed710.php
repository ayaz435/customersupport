<div class="favorite-list-item">
    <?php if($user): ?>
  
        <div data-id="<?php echo e($user->id); ?>" data-action="0" class="avatar av-m"

            style="background-image: url('<?php echo e(Chatify::getUserWithAvatar($user)->avatar); ?>');">
          </div>


         <?php if(Auth::user()->role === 'team'): ?>
            <p><?php echo e(strlen($user->cname) > 5 ? substr($user->cname,0,6).'..' : $user->cname); ?></p>
        <?php elseif(Auth::user()->role === 'user'): ?>
            <p><?php echo e(strlen($user->name) > 5 ? substr($user->name,0,6).'..' : $user->name); ?></p>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php /**PATH /home/xlserp/public_html/customersupport/chat/resources/views/vendor/Chatify/layouts/favorite.blade.php ENDPATH**/ ?>