<?php echo $__env->make('Chatify::layouts.headLinks', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<style>.toaster {
    position: fixed;
    top: 20px; /* Adjust position as needed */
    right: -100%; /* Initially, it is hidden off the screen */
    background-color: #4CAF50;
    color: white;
    padding: 15px;
    border-radius: 5px;
    z-index: 9999;
    transition: right 0.5s ease; /* Smooth transition when showing/hiding */
}

.toaster.visible {
    right: 20px; /* Adjust position as needed */
}</style>
<div class="messenger">
   
    
    <div class="messenger-listView <?php echo e(!!$id ? 'conversation-active' : ''); ?>">
        
        <div class="m-header">
            <nav>
                <a href="#"><img  class="mx-2" src="<?php echo e(asset('img/logo.png')); ?>" width="40%" alt="" > </a>
                
                <nav class="m-header-right">
                    <a href="#"><i class="fas fa-cog settings-btn"></i></a>
                    <a href="#" class="listView-x"><i class="fas fa-times"></i></a>
                </nav>
            </nav><div id="toaster" class="toaster hidden">
    <p id="toasterMessage"></p>
</div>
            
            <input type="text" class="messenger-search" placeholder="Search" />
            
            
        </div>
        
        <div class="m-body contacts-container">
           
           
           <div class="show messenger-tab users-tab app-scroll" data-view="users">
               
               <div class="favorites-section">
                <p class="messenger-title mt-3 "><span>
                 <?php if(Auth::user()->role === 'team'): ?>
            Company Name
        <?php elseif(Auth::user()->role === 'user'): ?>
          Team Members
        <?php endif; ?>
               </span></p>
                <div class="messenger-favorites app-scroll-hidden"></div>
               </div>
               
               <p class="messenger-title"><span>Your Space</span></p>
               <?php echo view('Chatify::layouts.listItem', ['get' => 'saved']); ?>

               
               <p class="messenger-title"><span>All Messages</span></p>
               <div class="listOfContacts" style="width: 100%;height: calc(100% - 272px);position: relative;"></div>
           </div>
             
           <div class="messenger-tab search-tab app-scroll" data-view="search">
                
                <p class="messenger-title"><span>Search</span></p>
                <div class="search-records">
                    <p class="message-hint center-el"><span>Type to search..</span></p>
                </div>
             </div>
        </div>
    </div>

    
    <div class="messenger-messagingView">
        
        <div class="m-header m-header-messaging">
            <nav class="chatify-d-flex chatify-justify-content-between chatify-align-items-center">
                
                <div class="chatify-d-flex chatify-justify-content-between chatify-align-items-center">
                    <a href="#" class="show-listView"><i class="fas fa-arrow-left"></i></a>
                    <?php if(Auth::user()->role === 'team'): ?>
          <a href="#" >Customer Service</a>
        <?php elseif(Auth::user()->role === 'user'): ?>
          <a href="#" ><span class="text-success mx-2 fs-5"><?php echo e(auth()->user()->cname); ?>:  <span></a> <span class="mt-1">Connects with CustomerService</span>
        <?php endif; ?>
                   
                </div>
                
                <nav class="m-header-right">
                    <a href="#" class="add-to-favorite"><i class="fas fa-star"></i></a>
                    <a href="/"><i class="fas fa-home"></i></a>
                    <a href="#" class="show-infoSide"><i class="fas fa-info-circle"></i></a>
                    <form class="mt-3" method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>

                        <?php if (isset($component)) { $__componentOriginald69b52d99510f1e7cd3d80070b28ca18 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.responsive-nav-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                            this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                            this.closest(\'form\').submit();']); ?>
                            <?php echo e(__('Logout')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $attributes = $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $component = $__componentOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
                    </form>
                </nav>
            </nav>
            
            <div class="internet-connection">
                <span class="ic-connected">Connected</span>
                <span class="ic-connecting">Connecting...</span>
                <span class="ic-noInternet">No internet access</span>
            </div>
        </div>

        
        <div class="m-body messages-container app-scroll">
            <div class="messages">
           
                <p class="message-hint center-el"><span>
         <?php if(Auth::user()->role === 'team'): ?>
             Hi Welcome to CustomerSupport Chat <br>
                Plz Click on Clients Icon To start Chat
        <?php elseif(Auth::user()->role === 'user'): ?>
         Hi Welcome to CustomerSupport Chat <br>
                Plz Click on Team Member Icon To start Chat
        <?php endif; ?>
               
            </span></p>
            </div>
            
            <div class="typing-indicator">
                <div class="message-card typing">
                    <div class="message">
                        <span class="typing-dots">
                            <span class="dot dot-1"></span>
                            <span class="dot dot-2"></span>
                            <span class="dot dot-3"></span>
                        </span>
                    </div>
                </div>
            </div>

        </div>
        
        <?php echo $__env->make('Chatify::layouts.sendForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    
    <div class="messenger-infoView app-scroll">
        
        <nav>
            <p>User Details</p>
            <a href="#"><i class="fas fa-times"></i></a>
        </nav>
        <?php echo view('Chatify::layouts.info')->render(); ?>

    </div>
</div>
    



<?php echo $__env->make('Chatify::layouts.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Chatify::layouts.footerLinks', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/laravel-echo@1.11.3/dist/echo.js"></script>
<script>
    // Include Laravel Echo configuration
window.Echo = new Echo({
    broadcaster: 'pusher',
    key: process.env.MIX_PUSHER_APP_KEY,
    cluster: process.env.MIX_PUSHER_APP_CLUSTER,
    encrypted: true,
});

window.Echo.channel('chat')
    .listen('VoiceMessageSent', (event) => {
        console.log(event.voiceMessage);
        // Handle voice message on the front end
    });

</script>
<script src="https://cdn.jsdelivr.net/npm/recorder-js/dist/recorder.js"></script>
    <script src="https://cdn.rawgit.com/mattdiamond/Recorderjs/08e7abd9/dist/recorder.js"></script>
<script>
 let countdownTimer; // Variable to hold the countdown timer
let secondsLeft = 30; // Initial value for the countdown timer
let alertShown = false; // Variable to track if the alert has been shown
var messageShown = false;

function startCountdown() {
    countdownTimer = setInterval(() => {
        if (secondsLeft === 0) {
            clearInterval(countdownTimer);
            if (!alertShown) {
                // Automatically send the message when the countdown reaches zero
                sendMessage("Please wait, a team member is busy. You will receive a reply soon.");
                alertShown = true;
            }
            return;
        }
        secondsLeft--;
    }, 1000);
}
function showToaster(message) {
    const toaster = document.getElementById("toaster");
    const toasterMessage = document.getElementById("toasterMessage");
    toasterMessage.textContent = message;
    toaster.classList.add("visible");

    // Automatically hide the toaster after 10 seconds
    setTimeout(() => {
        toaster.classList.remove("visible");
    }, 10000); // 10 seconds

    // Optionally, you can also clear the timeout if the toaster is manually dismissed
    // This ensures that if the user closes the toaster before the timeout, it won't hide automatically
    toaster.addEventListener("click", () => {
        clearTimeout(timeoutId);
        toaster.classList.remove("visible");
    });
}

function resetCountdown() {
    clearInterval(countdownTimer);
    secondsLeft = 30;
    alertShown = false; // Reset the alertShown variable
}

function sendMessage() {
    temporaryMsgId += 1;
    let tempID = `temp_${temporaryMsgId}`;
    let hasFile = !!$(".upload-attachment").val();
    const inputValue = $.trim(messageInput.val());

    const formData = new FormData($("#message-form")[0]);
    formData.append("id", getMessengerId());
    formData.append("temporaryMsgId", tempID);
    formData.append("_token", csrfToken);

    const handleSuccess = (data) => {
       console.log(data) 
        if (data.error.status > 0) {
            alert(data.error.message); // Display error message
            errorMessageCard(tempID);
            console.error(data.error.message);
        } else {
            updateContactItem(getMessengerId());

            const tempMsgCardElement = messagesContainer.find(`.message-card[data-id=${tempID}]`);

            if (data.message) {
                tempMsgCardElement.before(data.message);
            }
            tempMsgCardElement.remove();

            scrollToBottom(messagesContainer);
            sendContactItemUpdates(true);

            // Handle countdown based on roles
            if (data.userRole === "team") {
                resetCountdown();
            } else if (data.userRole === "user") {
                resetCountdown();
                startCountdown();
            }

            // Display formatted time difference (if provided)
            if (data.formatted_time) {
                console.log(`Time difference: ${data.formatted_time}`);
            }
        }
    };

    const handleError = () => {
        errorMessageCard(tempID);
        console.error("Failed sending the message! Please, check your server response.");
    };

    const beforeSend = () => {
        $(".messages").find(".message-hint").hide();

        if (hasFile) {
            messagesContainer.find(".messages").append(
                sendTempMessageCard(inputValue + "\n" + loadingSVG("28px"), tempID)
            );
        } else {
            messagesContainer.find(".messages").append(sendTempMessageCard(inputValue, tempID));
        }
        scrollToBottom(messagesContainer);
        messageInput.css({ height: "42px" });

        $("#message-form").trigger("reset");
        cancelAttachment();
        messageInput.focus();
    };

    const ajaxOptions = {
        url: $("#message-form").attr("action"),
        method: "POST",
        data: formData,
        dataType: "JSON",
        processData: false,
        contentType: false,
        beforeSend: beforeSend,
        success: handleSuccess,
        error: handleError,
    };

    // Check countdown timer logic
    if (secondsLeft === 0) {
        formData.append("message", "Please wait, a team member is busy. You will receive a reply soon.");
    }

    $.ajax(ajaxOptions);

    return false;
}




$(document).ready(function() {
    fetchContacts();

    function fetchContacts() {
        $.ajax({
            url: url + "/getContactsitems", // Update this to your actual endpoint
            method: "GET",
            dataType: "JSON",
            success: (data) => {
                $(".listOfContacts").empty(); // Clear existing contacts
                if (data.contacts && data.contacts.length > 0) {
                    data.contacts.forEach(contact => {
                        $(".listOfContacts").prepend(contact.contact_item);
                    });
                    $(".listOfContacts").find(".message-hint").hide();
                } else {
                    $(".listOfContacts").find(".message-hint").show();
                }
                cssMediaQueries(); // Update responsive design
            },
            error: (error) => {
                console.error(error);
            },
        });
    }
});



</script>
 <?php /**PATH /home/xlserp/public_html/customersupport/chat/resources/views/vendor/Chatify/pages/app.blade.php ENDPATH**/ ?>