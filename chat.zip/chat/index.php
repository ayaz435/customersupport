<?php
require_once __DIR__.'/public/index.php';